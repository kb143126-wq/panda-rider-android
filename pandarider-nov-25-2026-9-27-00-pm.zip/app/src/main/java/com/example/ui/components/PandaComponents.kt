package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.DeliveryStatus
import com.example.data.model.VehicleType
import com.example.data.model.formatCents
import com.example.ui.theme.PandaAmber
import com.example.ui.theme.PandaMint
import com.example.ui.theme.PandaPink
import java.util.Locale

fun launchGoogleMapsNavigation(
    context: Context,
    lat: Double,
    lng: Double,
    label: String,
    vehicleType: VehicleType
) {
    val navUri = Uri.parse("google.navigation:q=$lat,$lng&mode=${vehicleType.navMode}")
    val mapIntent = Intent(Intent.ACTION_VIEW, navUri).apply {
        setPackage("com.google.android.apps.maps")
    }
    try {
        if (mapIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(mapIntent)
        } else {
            val geoUri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${Uri.encode(label)})")
            context.startActivity(Intent(Intent.ACTION_VIEW, geoUri))
        }
    } catch (_: Exception) {
        Toast.makeText(context, "Open Maps to navigate to $label", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun GoogleMapsNavigationButton(
    lat: Double,
    lng: Double,
    label: String,
    vehicleType: VehicleType,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    FilledTonalButton(
        onClick = { launchGoogleMapsNavigation(context, lat, lng, label, vehicleType) },
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer,
            contentColor = MaterialTheme.colorScheme.onSecondaryContainer
        ),
        modifier = modifier
            .height(48.dp)
            .testTag("google_maps_nav_button")
    ) {
        Icon(
            imageVector = Icons.Rounded.Navigation,
            contentDescription = "Launch Google Maps navigation",
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = stringResource(R.string.navigate_maps),
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
fun StatusBadge(
    status: DeliveryStatus,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (status) {
        DeliveryStatus.COMPLETED -> PandaMint.copy(alpha = 0.16f) to PandaMint
        DeliveryStatus.CANCELLED -> MaterialTheme.colorScheme.error.copy(alpha = 0.16f) to MaterialTheme.colorScheme.error
        DeliveryStatus.HEADING_TO_PICKUP, DeliveryStatus.AT_PICKUP -> PandaPink.copy(alpha = 0.16f) to PandaPink
        DeliveryStatus.HEADING_TO_DROPOFF, DeliveryStatus.AT_DROPOFF -> PandaAmber.copy(alpha = 0.18f) to PandaAmber
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(50),
        modifier = modifier
    ) {
        Text(
            text = status.label,
            color = fg,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun DeliveryTimelineStepper(
    currentStatus: DeliveryStatus,
    modifier: Modifier = Modifier
) {
    val steps = listOf(
        "To Pickup" to DeliveryStatus.HEADING_TO_PICKUP,
        "At Store" to DeliveryStatus.AT_PICKUP,
        "En Route" to DeliveryStatus.HEADING_TO_DROPOFF,
        "Drop-off" to DeliveryStatus.AT_DROPOFF
    )
    val currentIndex = steps.indexOfFirst { it.second == currentStatus }.coerceAtLeast(0)

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { idx, (title, _) ->
            val reached = idx <= currentIndex
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(50))
                        .background(
                            if (reached) PandaPink
                            else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (reached) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}

data class DailyEarningsBar(
    val dayLabel: String,
    val amountCents: Long
)

@Composable
fun EarningsBarChart(
    bars: List<DailyEarningsBar>,
    selectedIndex: Int,
    onSelectDay: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val maxVal = (bars.maxOfOrNull { it.amountCents } ?: 100L).coerceAtLeast(100L)
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val trackColor = MaterialTheme.colorScheme.surfaceVariant

    Column(modifier = modifier.fillMaxWidth()) {
        val selected = bars.getOrNull(selectedIndex)
        if (selected != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${selected.dayLabel} Payout",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = formatCents(selected.amountCents),
                    style = MaterialTheme.typography.titleMedium,
                    color = primaryColor,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            bars.forEachIndexed { index, item ->
                val targetRatio = (item.amountCents.toFloat() / maxVal.toFloat()).coerceIn(0.08f, 1f)
                val animatedRatio by animateFloatAsState(
                    targetValue = targetRatio,
                    animationSpec = spring(dampingRatio = 0.72f),
                    label = "barRatio"
                )
                val isSelected = index == selectedIndex
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onSelectDay(index) }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Canvas(
                        modifier = Modifier
                            .width(24.dp)
                            .height(112.dp)
                    ) {
                        drawRoundRect(
                            color = trackColor,
                            topLeft = Offset.Zero,
                            size = size,
                            cornerRadius = CornerRadius(14f, 14f)
                        )
                        val barHeight = size.height * animatedRatio
                        val brush = if (isSelected) {
                            Brush.verticalGradient(listOf(primaryColor, secondaryColor))
                        } else {
                            Brush.verticalGradient(
                                listOf(
                                    primaryColor.copy(alpha = 0.55f),
                                    primaryColor.copy(alpha = 0.35f)
                                )
                            )
                        }
                        drawRoundRect(
                            brush = brush,
                            topLeft = Offset(0f, size.height - barHeight),
                            size = Size(size.width, barHeight),
                            cornerRadius = CornerRadius(14f, 14f)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = item.dayLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) primaryColor else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

fun formatShiftTimer(seconds: Long): String {
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, secs)
}

@Composable
fun OnlineDot(online: Boolean) {
    Box(
        modifier = Modifier
            .size(10.dp)
            .clip(CircleShape)
            .background(if (online) PandaMint else Color(0xFF8B8E9B))
    )
}
