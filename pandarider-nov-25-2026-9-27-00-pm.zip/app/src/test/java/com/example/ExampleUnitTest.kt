package com.example

import com.example.data.dispatch.DispatchOfferEngine
import com.example.data.model.DeliveryStatus
import com.example.data.model.VehicleType
import com.example.data.model.formatCents
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun dispatchOfferEngine_generatesValidOffer() {
        val offer = DispatchOfferEngine.generateOffer(
            riderCenter = DispatchOfferEngine.DEFAULT_CITY_HUB,
            sequenceIndex = 2,
            maxRadiusKm = 8
        )
        assertTrue(offer.orderCode.startsWith("FP-"))
        assertTrue(offer.distanceKm > 0.0)
        assertEquals(
            offer.basePayCents + offer.tipCents + offer.surgeBonusCents,
            offer.totalPayCents
        )
    }

    @Test
    fun enumsAndFormatters_handleUnknownRawValuesSafely() {
        assertEquals(VehicleType.E_BIKE, VehicleType.fromRaw("UNKNOWN"))
        assertEquals(DeliveryStatus.HEADING_TO_PICKUP, DeliveryStatus.fromRaw("UNKNOWN"))
        assertEquals("$12.50", formatCents(1250L))
    }
}
