package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GpsFixed
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material.icons.rounded.Traffic
import androidx.compose.material.icons.rounded.TwoWheeler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.R
import com.example.data.dispatch.DispatchOfferEngine
import com.example.data.model.DeliveryOffer
import com.example.data.model.DeliveryStatus
import com.example.data.model.RiderDelivery
import com.example.data.model.RiderProfile
import com.example.data.model.formatCents
import com.example.data.model.formatKm
import com.example.ui.components.DeliveryTimelineStepper
import com.example.ui.components.GoogleMapsNavigationButton
import com.example.ui.components.OnlineDot
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatShiftTimer
import com.example.ui.theme.PandaAmber
import com.example.ui.theme.PandaMint
import com.example.ui.theme.PandaPink
import com.example.ui.viewmodel.RiderViewModel
import com.example.ui.viewmodel.UiState
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.maps.android.compose.Circle
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.launch

@Composable
fun DispatchScreen(
    profileState: UiState<RiderProfile?>,
    deliveriesState: UiState<List<RiderDelivery>>,
    riderLocation: LatLng,
    hasLocationPermission: Boolean,
    pendingOffer: DeliveryOffer?,
    offerCountdownSec: Int,
    shiftSeconds: Long,
    isBusy: Boolean,
    viewModel: RiderViewModel,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var showTraffic by remember { mutableStateOf(false) }
    var useSatellite by remember { mutableStateOf(false) }
    var showCancelDialog by remember { mutableStateOf<RiderDelivery?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        viewModel.onLocationPermissionResult(granted)
    }

    val profile = (profileState as? UiState.Success)?.data
    val deliveries = (deliveriesState as? UiState.Success)?.data.orEmpty()
    val activeDelivery = deliveries.firstOrNull { it.statusEnum.isActive }
    val todayEarningsCents = deliveries
        .filter { it.statusEnum == DeliveryStatus.COMPLETED }
        .sumOf { it.totalPayCents }

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(riderLocation, 14.2f)
    }

    LaunchedEffect(activeDelivery?.id, pendingOffer?.offerId, riderLocation) {
        val points = buildList {
            add(riderLocation)
            if (activeDelivery != null) {
                add(LatLng(activeDelivery.restaurantLat, activeDelivery.restaurantLng))
                add(LatLng(activeDelivery.dropoffLat, activeDelivery.dropoffLng))
            } else if (pendingOffer != null) {
                add(LatLng(pendingOffer.restaurantLat, pendingOffer.restaurantLng))
                add(LatLng(pendingOffer.dropoffLat, pendingOffer.dropoffLng))
            }
        }
        if (points.size > 1) {
            val bounds = LatLngBounds.builder().apply { points.forEach { include(it) } }.build()
            try {
                cameraPositionState.animate(CameraUpdateFactory.newLatLngBounds(bounds, 140))
            } catch (_: Exception) {
                cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(riderLocation, 14f))
            }
        } else {
            cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(riderLocation, 14.2f))
        }
    }

    val mapsKeyMissing = BuildConfig.MAPS_API_KEY.isBlank() || BuildConfig.MAPS_API_KEY == "MY_MAPS_API_KEY"
    val hotspots = remember(riderLocation) { DispatchOfferEngine.hotspotZones(riderLocation) }

    Box(modifier = modifier.fillMaxSize()) {
        GoogleMap(
            modifier = Modifier
                .fillMaxSize()
                .testTag("google_map_view"),
            cameraPositionState = cameraPositionState,
            properties = MapProperties(
                isMyLocationEnabled = hasLocationPermission,
                isTrafficEnabled = showTraffic,
                mapType = if (useSatellite) MapType.HYBRID else MapType.NORMAL
            ),
            uiSettings = MapUiSettings(
                myLocationButtonEnabled = false,
                zoomControlsEnabled = false,
                compassEnabled = true,
                mapToolbarEnabled = false
            )
        ) {
            // Rider marker (always visible even before GPS permission is granted)
            Marker(
                state = MarkerState(position = riderLocation),
                title = "Your Rider Location",
                snippet = profile?.vehicleEnum?.label ?: "E-Bike",
                icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)
            )

            // Active delivery or pending offer route pins & polyline
            val pickupLatLng = activeDelivery?.let { LatLng(it.restaurantLat, it.restaurantLng) }
                ?: pendingOffer?.let { LatLng(it.restaurantLat, it.restaurantLng) }
            val dropoffLatLng = activeDelivery?.let { LatLng(it.dropoffLat, it.dropoffLng) }
                ?: pendingOffer?.let { LatLng(it.dropoffLat, it.dropoffLng) }

            if (pickupLatLng != null && dropoffLatLng != null) {
                Marker(
                    state = MarkerState(position = pickupLatLng),
                    title = activeDelivery?.restaurantName ?: pendingOffer?.restaurantName ?: "Pickup",
                    snippet = activeDelivery?.restaurantAddress ?: pendingOffer?.restaurantAddress,
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ROSE)
                )
                Marker(
                    state = MarkerState(position = dropoffLatLng),
                    title = activeDelivery?.customerName ?: pendingOffer?.customerName ?: "Drop-off",
                    snippet = activeDelivery?.dropoffAddress ?: pendingOffer?.dropoffAddress,
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)
                )
                Polyline(
                    points = listOf(riderLocation, pickupLatLng, dropoffLatLng),
                    color = PandaPink,
                    width = 11f
                )
            } else {
                // Show demand hotspot circles when waiting for offers
                hotspots.forEach { (label, point) ->
                    Circle(
                        center = point,
                        radius = 320.0,
                        fillColor = PandaPink.copy(alpha = 0.14f),
                        strokeColor = PandaPink.copy(alpha = 0.6f),
                        strokeWidth = 3f
                    )
                    Marker(
                        state = MarkerState(position = point),
                        title = label,
                        snippet = "High demand zone",
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)
                    )
                }
            }
        }

        // Top floating status bar + controls
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .widthIn(max = 580.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                shadowElevation = 6.dp,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OnlineDot(online = profile?.online == true)
                        Column {
                            Text(
                                text = if (profile?.online == true) {
                                    "${stringResource(R.string.status_online)} • ${formatShiftTimer(shiftSeconds)}"
                                } else {
                                    stringResource(R.string.status_offline)
                                },
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${profile?.preferredZone ?: "Downtown Central"} • ${profile?.vehicleEnum?.label ?: "E-Bike"}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = PandaMint.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = formatCents(todayEarningsCents),
                                style = MaterialTheme.typography.labelLarge,
                                color = PandaMint,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                        FilledIconButton(
                            onClick = { viewModel.toggleOnline(profile?.online != true) },
                            enabled = !isBusy && profile != null,
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = if (profile?.online == true) PandaMint else PandaPink,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("shift_toggle_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PowerSettingsNew,
                                contentDescription = if (profile?.online == true) "Go offline" else "Go online"
                            )
                        }
                    }
                }
            }

            if (mapsKeyMissing) {
                Surface(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                    shape = RoundedCornerShape(12.dp),
                    shadowElevation = 2.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Info,
                            contentDescription = null,
                            tint = PandaAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = stringResource(R.string.maps_key_hint),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Right-aligned map utility pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!hasLocationPermission) {
                    Surface(
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                        shape = RoundedCornerShape(50),
                        shadowElevation = 4.dp,
                        modifier = Modifier
                            .clickable {
                                permissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            }
                            .testTag("enable_gps_pill")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.GpsFixed,
                                contentDescription = "Enable GPS",
                                tint = PandaPink,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = stringResource(R.string.enable_location),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }

                FilledIconButton(
                    onClick = { showTraffic = !showTraffic },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (showTraffic) PandaPink else MaterialTheme.colorScheme.surface,
                        contentColor = if (showTraffic) Color.White else MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.Rounded.Traffic, contentDescription = "Toggle traffic layer")
                }
                Spacer(modifier = Modifier.width(6.dp))
                FilledIconButton(
                    onClick = { useSatellite = !useSatellite },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (useSatellite) PandaPink else MaterialTheme.colorScheme.surface,
                        contentColor = if (useSatellite) Color.White else MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.Rounded.Layers, contentDescription = "Toggle map style")
                }
                Spacer(modifier = Modifier.width(6.dp))
                FilledIconButton(
                    onClick = {
                        scope.launch {
                            cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(riderLocation, 15f))
                        }
                    },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.Rounded.MyLocation, contentDescription = "Center map on rider")
                }
            }
        }

        // Bottom Interactive Dispatch Sheet
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp)
                .widthIn(max = 580.dp)
        ) {
            when {
                profileState is UiState.Loading -> {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp))
                            Text("Syncing courier session...", style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }

                activeDelivery != null -> {
                    ActiveDeliveryCard(
                        delivery = activeDelivery,
                        profile = profile,
                        isBusy = isBusy,
                        onToggleItems = { viewModel.toggleItemsVerified(activeDelivery) },
                        onAdvance = { viewModel.advanceDelivery(activeDelivery) },
                        onCancelRequest = { showCancelDialog = activeDelivery }
                    )
                }

                profile?.online == true && pendingOffer != null -> {
                    IncomingOfferCard(
                        offer = pendingOffer,
                        countdownSec = offerCountdownSec,
                        isBusy = isBusy,
                        onAccept = { viewModel.acceptPendingOffer() },
                        onDecline = { viewModel.declineOffer() }
                    )
                }

                profile?.online == true -> {
                    WaitingForOfferCard(
                        zone = profile.preferredZone,
                        radiusKm = profile.maxRadiusKm.toInt(),
                        onFindOffer = { viewModel.dispatchNextOffer(profile.maxRadiusKm.toInt()) }
                    )
                }

                else -> {
                    OfflineShiftCard(
                        profile = profile,
                        isBusy = isBusy,
                        onGoOnline = { viewModel.toggleOnline(true) }
                    )
                }
            }
        }
    }

    showCancelDialog?.let { delivery ->
        AlertDialog(
            onDismissRequest = { showCancelDialog = null },
            title = { Text("Cancel ${delivery.orderCode}?") },
            text = { Text("Cancelling an active order returns it to the dispatch pool. Confirm cancellation?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.cancelActiveDelivery(delivery)
                        showCancelDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Cancel Order")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = null }) {
                    Text("Keep Order")
                }
            }
        )
    }
}

@Composable
private fun OfflineShiftCard(
    profile: RiderProfile?,
    isBusy: Boolean,
    onGoOnline: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        color = PandaPink.copy(alpha = 0.14f),
                        shape = CircleShape,
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.LocalFireDepartment,
                                contentDescription = null,
                                tint = PandaPink
                            )
                        }
                    }
                    Column {
                        Text(
                            text = "Peak Surge Active (+1.5x)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${profile?.preferredZone ?: "Downtown Central"} • High order volume",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onGoOnline,
                enabled = !isBusy && profile != null,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PandaPink),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("go_online_button")
            ) {
                Icon(Icons.Rounded.TwoWheeler, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.go_online), style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
private fun WaitingForOfferCard(
    zone: String,
    radiusKm: Int,
    onFindOffer: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Scanning $zone",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Dispatch radius: $radiusKm km • Hotspot zones highlighted on map",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 2.5.dp,
                    color = PandaMint
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedButton(
                onClick = onFindOffer,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("find_offer_button")
            ) {
                Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.find_offer))
            }
        }
    }
}

@Composable
private fun IncomingOfferCard(
    offer: DeliveryOffer,
    countdownSec: Int,
    isBusy: Boolean,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = PandaPink.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = "NEW OFFER • ${offer.orderCode}",
                        style = MaterialTheme.typography.labelSmall,
                        color = PandaPink,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
                Text(
                    text = "${countdownSec}s",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (countdownSec <= 10) MaterialTheme.colorScheme.error else PandaAmber,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { (countdownSec / 35f).coerceIn(0f, 1f) },
                color = PandaPink,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(50))
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = offer.restaurantName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${offer.restaurantAddress} -> ${offer.dropoffAddress}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = formatCents(offer.totalPayCents),
                        style = MaterialTheme.typography.headlineMedium,
                        color = PandaMint,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${formatKm(offer.distanceKm)} • ~${offer.etaMinutes} min",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Base ${formatCents(offer.basePayCents)} + Surge ${formatCents(offer.surgeBonusCents)} + Tip ${formatCents(offer.tipCents)} • ${offer.itemCount} items",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onDecline,
                    enabled = !isBusy,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(0.38f)
                        .height(50.dp)
                        .testTag("decline_offer_button")
                ) {
                    Text(stringResource(R.string.decline_order))
                }
                Button(
                    onClick = onAccept,
                    enabled = !isBusy,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PandaPink),
                    modifier = Modifier
                        .weight(0.62f)
                        .height(50.dp)
                        .testTag("accept_offer_button")
                ) {
                    Text(stringResource(R.string.accept_order), style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
private fun ActiveDeliveryCard(
    delivery: RiderDelivery,
    profile: RiderProfile?,
    isBusy: Boolean,
    onToggleItems: () -> Unit,
    onAdvance: () -> Unit,
    onCancelRequest: () -> Unit
) {
    val status = delivery.statusEnum
    val isPickupPhase = status == DeliveryStatus.HEADING_TO_PICKUP || status == DeliveryStatus.AT_PICKUP
    val navLat = if (isPickupPhase) delivery.restaurantLat else delivery.dropoffLat
    val navLng = if (isPickupPhase) delivery.restaurantLng else delivery.dropoffLng
    val navLabel = if (isPickupPhase) delivery.restaurantName else delivery.dropoffAddress

    val primaryButtonText = when (status) {
        DeliveryStatus.HEADING_TO_PICKUP -> stringResource(R.string.arrived_restaurant)
        DeliveryStatus.AT_PICKUP -> stringResource(R.string.confirm_pickup)
        DeliveryStatus.HEADING_TO_DROPOFF -> stringResource(R.string.arrived_customer)
        DeliveryStatus.AT_DROPOFF -> "${stringResource(R.string.complete_delivery)} (+${formatCents(delivery.totalPayCents)})"
        DeliveryStatus.COMPLETED, DeliveryStatus.CANCELLED -> ""
    }

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = delivery.orderCode,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    StatusBadge(status = status)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = formatCents(delivery.totalPayCents),
                        style = MaterialTheme.typography.titleMedium,
                        color = PandaMint,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    FilledIconButton(
                        onClick = onCancelRequest,
                        enabled = !isBusy,
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("cancel_delivery_button")
                    ) {
                        Icon(Icons.Rounded.Close, contentDescription = "Cancel delivery")
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            DeliveryTimelineStepper(currentStatus = status)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = PandaPink.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.size(42.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isPickupPhase) Icons.Rounded.Storefront else Icons.Rounded.Restaurant,
                            contentDescription = null,
                            tint = PandaPink
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isPickupPhase) delivery.restaurantName else delivery.customerName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isPickupPhase) delivery.restaurantAddress else delivery.dropoffAddress,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (!isPickupPhase && delivery.dropoffNotes.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Drop-off note: ${delivery.dropoffNotes}",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            if (status == DeliveryStatus.AT_PICKUP) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = if (delivery.itemsVerified) PandaMint.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = !isBusy) { onToggleItems() }
                        .testTag("verify_items_row")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = if (delivery.itemsVerified) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                            contentDescription = "Verify sealed bag items",
                            tint = if (delivery.itemsVerified) PandaMint else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Verify ${delivery.itemCount} items & thermal seal",
                                style = MaterialTheme.typography.labelLarge
                            )
                            Text(
                                text = delivery.itemsSummary,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GoogleMapsNavigationButton(
                    lat = navLat,
                    lng = navLng,
                    label = navLabel,
                    vehicleType = profile?.vehicleEnum ?: com.example.data.model.VehicleType.E_BIKE,
                    modifier = Modifier.weight(0.38f)
                )
                Button(
                    onClick = onAdvance,
                    enabled = !isBusy && (status != DeliveryStatus.AT_PICKUP || delivery.itemsVerified),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (status == DeliveryStatus.AT_DROPOFF) PandaMint else PandaPink,
                        contentColor = if (status == DeliveryStatus.AT_DROPOFF) Color(0xFF0A1F17) else Color.White
                    ),
                    modifier = Modifier
                        .weight(0.62f)
                        .height(48.dp)
                        .testTag("advance_delivery_button")
                ) {
                    Text(
                        text = primaryButtonText,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
