package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.DeliveryOffer
import com.example.data.model.DeliveryStatus
import com.example.data.model.PayoutMethod
import com.example.data.model.RiderDelivery
import com.example.data.model.RiderPayout
import com.example.data.model.RiderProfile
import com.example.data.model.VehicleType
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class RiderRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun riderDoc(uid: String) = db.collection("riders").document(uid)

    fun observeProfile(userId: String): Flow<RiderProfile?> = flow {
        require(userId.isNotBlank()) { "Rider userId must not be blank" }
        val path = "riders/$userId"
        emitAll(
            riderDoc(userId)
                .snapshots()
                .map { snapshot ->
                    if (!snapshot.exists()) null
                    else snapshot.toObject(RiderProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observeDeliveries(userId: String): Flow<List<RiderDelivery>> = flow {
        require(userId.isNotBlank()) { "Rider userId must not be blank" }
        val path = "riders/$userId/deliveries"
        emitAll(
            riderDoc(userId)
                .collection("deliveries")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(RiderDelivery::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observePayouts(userId: String): Flow<List<RiderPayout>> = flow {
        require(userId.isNotBlank()) { "Rider userId must not be blank" }
        val path = "riders/$userId/payouts"
        emitAll(
            riderDoc(userId)
                .collection("payouts")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(RiderPayout::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun ensureProfileExists(displayName: String, email: String?): Result<Unit> {
        var docPath = "riders/${auth.currentUser?.uid ?: "unauthenticated"}"
        return try {
            val uid = requireUserId()
            val ref = riderDoc(uid)
            docPath = ref.path
            val snapshot = ref.get().await()
            if (!snapshot.exists()) {
                val safeName = displayName.trim().ifBlank { "Panda Rider" }.take(80)
                val safeEmail = email?.trim()?.take(120)
                val payload = mapOf(
                    "userId" to uid,
                    "displayName" to safeName,
                    "email" to safeEmail,
                    "vehicleType" to VehicleType.E_BIKE.name,
                    "preferredZone" to "Downtown Central",
                    "maxRadiusKm" to 8,
                    "online" to false,
                    "thermalBagVerified" to true,
                    "totalEarningsCents" to 0,
                    "completedDeliveries" to 0,
                    "ratingTenths" to 49,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                ref.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun setOnlineStatus(online: Boolean): Result<Unit> {
        var docPath = "riders/${auth.currentUser?.uid ?: "unauthenticated"}"
        return try {
            val uid = requireUserId()
            val ref = riderDoc(uid)
            docPath = ref.path
            ref.update(
                mapOf(
                    "online" to online,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updatePreferences(
        displayName: String,
        vehicleType: VehicleType,
        preferredZone: String,
        maxRadiusKm: Int,
        thermalBagVerified: Boolean
    ): Result<Unit> {
        var docPath = "riders/${auth.currentUser?.uid ?: "unauthenticated"}"
        return try {
            val uid = requireUserId()
            val safeName = displayName.trim().ifBlank { "Panda Rider" }.take(80)
            val safeZone = preferredZone.trim().ifBlank { "Downtown Central" }.take(60)
            val safeRadius = maxRadiusKm.coerceIn(1, 30)
            val ref = riderDoc(uid)
            docPath = ref.path
            ref.update(
                mapOf(
                    "displayName" to safeName,
                    "vehicleType" to vehicleType.name,
                    "preferredZone" to safeZone,
                    "maxRadiusKm" to safeRadius,
                    "thermalBagVerified" to thermalBagVerified,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun acceptOffer(offer: DeliveryOffer): Result<String> {
        var docPath = "riders/${auth.currentUser?.uid ?: "unauthenticated"}/deliveries"
        return try {
            val uid = requireUserId()
            val colRef = riderDoc(uid).collection("deliveries")
            val docRef = colRef.document()
            docPath = docRef.path
            val payload = mapOf(
                "userId" to uid,
                "orderCode" to offer.orderCode.take(20),
                "restaurantName" to offer.restaurantName.take(80),
                "restaurantAddress" to offer.restaurantAddress.take(160),
                "restaurantLat" to offer.restaurantLat,
                "restaurantLng" to offer.restaurantLng,
                "customerName" to offer.customerName.take(80),
                "dropoffAddress" to offer.dropoffAddress.take(160),
                "dropoffNotes" to offer.dropoffNotes.take(200),
                "dropoffLat" to offer.dropoffLat,
                "dropoffLng" to offer.dropoffLng,
                "itemsSummary" to offer.itemsSummary.take(200),
                "itemCount" to offer.itemCount.coerceIn(1, 50),
                "distanceKm" to offer.distanceKm.coerceIn(0.2, 100.0),
                "basePayCents" to offer.basePayCents,
                "tipCents" to offer.tipCents,
                "surgeBonusCents" to offer.surgeBonusCents,
                "totalPayCents" to offer.totalPayCents,
                "status" to DeliveryStatus.HEADING_TO_PICKUP.name,
                "itemsVerified" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun toggleItemsVerified(deliveryId: String, verified: Boolean): Result<Unit> {
        var docPath = "riders/${auth.currentUser?.uid ?: "unauthenticated"}/deliveries/$deliveryId"
        return try {
            val uid = requireUserId()
            require(deliveryId.isNotBlank()) { "Delivery ID must not be blank" }
            val ref = riderDoc(uid).collection("deliveries").document(deliveryId)
            docPath = ref.path
            ref.update(
                mapOf(
                    "itemsVerified" to verified,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun advanceDeliveryStatus(
        deliveryId: String,
        nextStatus: DeliveryStatus,
        itemsVerified: Boolean
    ): Result<Unit> {
        var docPath = "riders/${auth.currentUser?.uid ?: "unauthenticated"}/deliveries/$deliveryId"
        return try {
            val uid = requireUserId()
            require(deliveryId.isNotBlank()) { "Delivery ID must not be blank" }
            require(nextStatus != DeliveryStatus.COMPLETED) { "Use completeDelivery for completion" }
            val ref = riderDoc(uid).collection("deliveries").document(deliveryId)
            docPath = ref.path
            ref.update(
                mapOf(
                    "status" to nextStatus.name,
                    "itemsVerified" to itemsVerified,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun completeDelivery(delivery: RiderDelivery): Result<Unit> {
        var docPath = "riders/${auth.currentUser?.uid ?: "unauthenticated"}/deliveries/${delivery.id}"
        return try {
            val uid = requireUserId()
            require(delivery.id.isNotBlank()) { "Delivery ID must not be blank" }
            val delRef = riderDoc(uid).collection("deliveries").document(delivery.id)
            val profileRef = riderDoc(uid)
            docPath = delRef.path

            val batch = db.batch()
            batch.update(
                delRef,
                mapOf(
                    "status" to DeliveryStatus.COMPLETED.name,
                    "completedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                profileRef,
                mapOf(
                    "totalEarningsCents" to FieldValue.increment(delivery.totalPayCents),
                    "completedDeliveries" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun requestPayout(amountCents: Long, method: PayoutMethod): Result<Unit> {
        var docPath = "riders/${auth.currentUser?.uid ?: "unauthenticated"}/payouts"
        return try {
            val uid = requireUserId()
            require(amountCents > 0L) { "Payout amount must be positive" }
            val docRef = riderDoc(uid).collection("payouts").document()
            docPath = docRef.path
            docRef.set(
                mapOf(
                    "userId" to uid,
                    "amountCents" to amountCents,
                    "method" to method.name,
                    "status" to "PROCESSED",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }
}
