package com.example.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material.icons.automirrored.rounded.ReceiptLong
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.data.location.RiderLocationTracker
import com.example.data.model.VehicleType
import com.example.data.repository.RiderRepository
import com.example.ui.screens.DispatchScreen
import com.example.ui.screens.EarningsScreen
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.viewmodel.RiderViewModel
import com.example.ui.viewmodel.UiState
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.serialization.Serializable

@Serializable
data object DispatchRoute

@Serializable
data object OrdersRoute

@Serializable
data object EarningsRoute

@Serializable
data object ProfileRoute

private data class NavDestinationItem(
    val route: Any,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun PandaRiderShell(
    currentUserId: String,
    initialDisplayName: String,
    initialEmail: String?,
    onSignedOut: () -> Unit
) {
    val riderViewModel: RiderViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                RiderViewModel(
                    repository = RiderRepository(db),
                    locationTracker = RiderLocationTracker(app),
                    currentUserId = currentUserId,
                    initialDisplayName = initialDisplayName,
                    initialEmail = initialEmail
                )
            }
        }
    )

    val profileState by riderViewModel.profileState.collectAsStateWithLifecycle()
    val deliveriesState by riderViewModel.deliveriesState.collectAsStateWithLifecycle()
    val payoutsState by riderViewModel.payoutsState.collectAsStateWithLifecycle()
    val riderLocation by riderViewModel.riderLocation.collectAsStateWithLifecycle()
    val hasLocationPermission by riderViewModel.hasLocationPermission.collectAsStateWithLifecycle()
    val pendingOffer by riderViewModel.pendingOffer.collectAsStateWithLifecycle()
    val offerCountdownSec by riderViewModel.offerCountdownSec.collectAsStateWithLifecycle()
    val shiftSeconds by riderViewModel.shiftSeconds.collectAsStateWithLifecycle()
    val isBusy by riderViewModel.isBusy.collectAsStateWithLifecycle()
    val feedbackMessage by riderViewModel.feedbackMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(feedbackMessage) {
        feedbackMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            riderViewModel.clearFeedback()
        }
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val navItems = remember {
        listOf(
            NavDestinationItem(
                route = DispatchRoute,
                labelRes = R.string.nav_dispatch,
                selectedIcon = Icons.Rounded.Map,
                unselectedIcon = Icons.Outlined.Map,
                testTag = "nav_dispatch"
            ),
            NavDestinationItem(
                route = OrdersRoute,
                labelRes = R.string.nav_orders,
                selectedIcon = Icons.AutoMirrored.Rounded.ReceiptLong,
                unselectedIcon = Icons.AutoMirrored.Outlined.ReceiptLong,
                testTag = "nav_orders"
            ),
            NavDestinationItem(
                route = EarningsRoute,
                labelRes = R.string.nav_earnings,
                selectedIcon = Icons.Rounded.AccountBalanceWallet,
                unselectedIcon = Icons.Outlined.AccountBalanceWallet,
                testTag = "nav_earnings"
            ),
            NavDestinationItem(
                route = ProfileRoute,
                labelRes = R.string.nav_profile,
                selectedIcon = Icons.Rounded.Person,
                unselectedIcon = Icons.Outlined.Person,
                testTag = "nav_profile"
            )
        )
    }

    fun navigateTo(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val activeVehicle = (profileState as? UiState.Success)?.data?.vehicleEnum ?: VehicleType.E_BIKE

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (!useRail) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        navItems.forEach { item ->
                            val selected = currentDestination?.hasRoute(item.route::class) == true
                            val label = stringResource(item.labelRes)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label) },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
                        navItems.forEach { item ->
                            val selected = currentDestination?.hasRoute(item.route::class) == true
                            val label = stringResource(item.labelRes)
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label) },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    NavHost(
                        navController = navController,
                        startDestination = DispatchRoute
                    ) {
                        composable<DispatchRoute> {
                            DispatchScreen(
                                profileState = profileState,
                                deliveriesState = deliveriesState,
                                riderLocation = riderLocation,
                                hasLocationPermission = hasLocationPermission,
                                pendingOffer = pendingOffer,
                                offerCountdownSec = offerCountdownSec,
                                shiftSeconds = shiftSeconds,
                                isBusy = isBusy,
                                viewModel = riderViewModel
                            )
                        }
                        composable<OrdersRoute> {
                            OrdersScreen(
                                deliveriesState = deliveriesState,
                                vehicleType = activeVehicle
                            )
                        }
                        composable<EarningsRoute> {
                            EarningsScreen(
                                profileState = profileState,
                                deliveriesState = deliveriesState,
                                payoutsState = payoutsState,
                                isBusy = isBusy,
                                viewModel = riderViewModel
                            )
                        }
                        composable<ProfileRoute> {
                            ProfileScreen(
                                profileState = profileState,
                                isBusy = isBusy,
                                viewModel = riderViewModel,
                                onSignedOut = onSignedOut
                            )
                        }
                    }
                }
            }
        }
    }
}
