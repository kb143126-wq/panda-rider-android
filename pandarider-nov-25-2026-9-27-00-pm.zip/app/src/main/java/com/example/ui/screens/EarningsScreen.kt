package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.TrendingUp
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.DeliveryStatus
import com.example.data.model.PayoutMethod
import com.example.data.model.RiderDelivery
import com.example.data.model.RiderPayout
import com.example.data.model.RiderProfile
import com.example.data.model.formatCents
import com.example.ui.components.DailyEarningsBar
import com.example.ui.components.EarningsBarChart
import com.example.ui.theme.PandaMint
import com.example.ui.theme.PandaPink
import com.example.ui.theme.PandaPinkDeep
import com.example.ui.viewmodel.RiderViewModel
import com.example.ui.viewmodel.UiState
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun EarningsScreen(
    profileState: UiState<RiderProfile?>,
    deliveriesState: UiState<List<RiderDelivery>>,
    payoutsState: UiState<List<RiderPayout>>,
    isBusy: Boolean,
    viewModel: RiderViewModel,
    modifier: Modifier = Modifier
) {
    val profile = (profileState as? UiState.Success)?.data
    val deliveries = (deliveriesState as? UiState.Success)?.data.orEmpty()
    val payouts = (payoutsState as? UiState.Success)?.data.orEmpty()

    val completed = remember(deliveries) {
        deliveries.filter { it.statusEnum == DeliveryStatus.COMPLETED }
    }
    val totalEarnedCents = maxOf(
        profile?.totalEarningsCents ?: 0L,
        completed.sumOf { it.totalPayCents }
    )
    val totalCashedOutCents = payouts.sumOf { it.amountCents }
    val availableBalanceCents = (totalEarnedCents - totalCashedOutCents).coerceAtLeast(0L)

    val basePayTotal = completed.sumOf { it.basePayCents }
    val surgeTotal = completed.sumOf { it.surgeBonusCents }
    val tipTotal = completed.sumOf { it.tipCents }

    val weeklyBars = remember(completed) { buildLast7DaysBars(completed) }
    var selectedBarIndex by remember { mutableIntStateOf(6) }
    var showCashOutDialog by remember { mutableStateOf(false) }
    var selectedMethod by remember { mutableStateOf(PayoutMethod.INSTANT_BANK) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "Earnings & Payouts",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(PandaPink, PandaPinkDeep)
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Available Balance",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                                Surface(
                                    color = Color.White.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(50)
                                ) {
                                    Text(
                                        text = "${completed.size} trips",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = formatCents(availableBalanceCents),
                                style = MaterialTheme.typography.displaySmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Lifetime Earned",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.78f)
                                    )
                                    Text(
                                        text = formatCents(totalEarnedCents),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Button(
                                    onClick = { showCashOutDialog = true },
                                    enabled = !isBusy && availableBalanceCents > 0L,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.White,
                                        contentColor = PandaPinkDeep
                                    ),
                                    modifier = Modifier
                                        .height(48.dp)
                                        .testTag("cash_out_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.AccountBalanceWallet,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(stringResource(R.string.cash_out), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.TrendingUp,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "7-Day Earnings Activity",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        EarningsBarChart(
                            bars = weeklyBars,
                            selectedIndex = selectedBarIndex,
                            onSelectDay = { selectedBarIndex = it }
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PayStatCard("Base Pay", formatCents(basePayTotal), Modifier.weight(1f))
                    PayStatCard("Surge Boost", formatCents(surgeTotal), Modifier.weight(1f))
                    PayStatCard("Tips (100%)", formatCents(tipTotal), Modifier.weight(1f))
                }
            }

            item {
                Text(
                    text = "Recent Cash-Outs",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (payouts.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "No cash-outs yet. Complete deliveries and tap Cash Out whenever you want instant payout.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(payouts, key = { it.id }) { payout ->
                    val dateStr = remember(payout.createdAt) {
                        val d = payout.createdAt?.toDate()
                        if (d != null) SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(d) else "Processed"
                    }
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = payout.methodEnum.label,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "$dateStr • ${payout.status}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = formatCents(payout.amountCents),
                                style = MaterialTheme.typography.titleMedium,
                                color = PandaMint,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCashOutDialog) {
        AlertDialog(
            onDismissRequest = { showCashOutDialog = false },
            title = { Text("Cash Out ${formatCents(availableBalanceCents)}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Choose your payout destination:")
                    PayoutMethod.entries.forEach { method ->
                        val selected = selectedMethod == method
                        Surface(
                            color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedMethod = method }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = if (selected) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(method.label, style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.requestCashOut(availableBalanceCents, selectedMethod)
                        showCashOutDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PandaPink)
                ) {
                    Text("Confirm Payout")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCashOutDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun PayStatCard(title: String, amount: String, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = amount,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun buildLast7DaysBars(completed: List<RiderDelivery>): List<DailyEarningsBar> {
    val cal = Calendar.getInstance()
    val dayFmt = SimpleDateFormat("EEE", Locale.US)
    val keyFmt = SimpleDateFormat("yyyyMMdd", Locale.US)

    val totalsByDay = mutableMapOf<String, Long>()
    completed.forEach { del ->
        val date = (del.completedAt ?: del.createdAt)?.toDate() ?: return@forEach
        val key = keyFmt.format(date)
        totalsByDay[key] = (totalsByDay[key] ?: 0L) + del.totalPayCents
    }

    val bars = mutableListOf<DailyEarningsBar>()
    for (offset in 6 downTo 0) {
        val c = cal.clone() as Calendar
        c.add(Calendar.DAY_OF_YEAR, -offset)
        val key = keyFmt.format(c.time)
        val label = dayFmt.format(c.time)
        bars.add(DailyEarningsBar(dayLabel = label, amountCents = totalsByDay[key] ?: 0L))
    }
    return bars
}
