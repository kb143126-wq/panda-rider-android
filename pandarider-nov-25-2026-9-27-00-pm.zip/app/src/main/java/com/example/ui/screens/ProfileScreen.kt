package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.data.model.RiderProfile
import com.example.data.model.VehicleType
import com.example.data.model.formatCents
import com.example.ui.auth.signOut
import com.example.ui.theme.PandaAmber
import com.example.ui.theme.PandaPink
import com.example.ui.viewmodel.RiderViewModel
import com.example.ui.viewmodel.UiState
import kotlin.math.roundToInt

private val ZONES = listOf(
    "Downtown Central",
    "SoMa District",
    "Midtown Hub",
    "Harbor Bay"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    profileState: UiState<RiderProfile?>,
    isBusy: Boolean,
    viewModel: RiderViewModel,
    onSignedOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val profile = (profileState as? UiState.Success)?.data
    var displayName by remember { mutableStateOf("") }
    var vehicleType by remember { mutableStateOf(VehicleType.E_BIKE) }
    var preferredZone by remember { mutableStateOf("Downtown Central") }
    var maxRadiusKm by remember { mutableFloatStateOf(8f) }
    var thermalBag by remember { mutableStateOf(true) }

    LaunchedEffect(profile?.userId, profile?.updatedAt) {
        if (profile != null) {
            displayName = profile.displayName
            vehicleType = profile.vehicleEnum
            preferredZone = profile.preferredZone
            maxRadiusKm = profile.maxRadiusKm.toFloat()
            thermalBag = profile.thermalBagVerified
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "Courier Profile",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_rider_avatar),
                            contentDescription = "Rider profile avatar",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = profile?.displayName?.ifBlank { "Panda Rider" } ?: "Panda Rider",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = profile?.email?.ifBlank { "Verified Courier" } ?: "Verified Courier",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Star,
                                    contentDescription = null,
                                    tint = PandaAmber,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "${profile?.ratingFormatted ?: "4.9"} • ${profile?.completedDeliveries ?: 0} trips • ${formatCents(profile?.totalEarningsCents ?: 0L)}",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Dispatch & Vehicle Preferences",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedTextField(
                            value = displayName,
                            onValueChange = { displayName = it.take(80) },
                            label = { Text("Courier Display Name") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("display_name_input")
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Vehicle Mode", style = MaterialTheme.typography.labelLarge)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                VehicleType.entries.forEach { type ->
                                    FilterChip(
                                        selected = vehicleType == type,
                                        onClick = { vehicleType = type },
                                        label = { Text(type.label) },
                                        modifier = Modifier.testTag("vehicle_${type.name.lowercase()}")
                                    )
                                }
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Preferred Zone", style = MaterialTheme.typography.labelLarge)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                ZONES.forEach { zone ->
                                    FilterChip(
                                        selected = preferredZone == zone,
                                        onClick = { preferredZone = zone },
                                        label = { Text(zone) }
                                    )
                                }
                            }
                        }

                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Max Dispatch Radius", style = MaterialTheme.typography.labelLarge)
                                Text(
                                    text = "${maxRadiusKm.roundToInt()} km",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = PandaPink,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Slider(
                                value = maxRadiusKm,
                                onValueChange = { maxRadiusKm = it },
                                valueRange = 2f..20f,
                                steps = 17
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Thermal Bag Equipped", style = MaterialTheme.typography.labelLarge)
                                Text(
                                    text = "Unlock hot-food & large order batches",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = thermalBag,
                                onCheckedChange = { thermalBag = it },
                                modifier = Modifier.testTag("thermal_bag_switch")
                            )
                        }

                        Button(
                            onClick = {
                                viewModel.savePreferences(
                                    displayName = displayName,
                                    vehicleType = vehicleType,
                                    preferredZone = preferredZone,
                                    maxRadiusKm = maxRadiusKm.roundToInt(),
                                    thermalBagVerified = thermalBag
                                )
                            },
                            enabled = !isBusy && profile != null,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PandaPink),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("save_preferences_button")
                        ) {
                            Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.save_preferences))
                        }
                    }
                }
            }

            item {
                OutlinedButton(
                    onClick = {
                        signOut(
                            credentialManager = credentialManager,
                            scope = scope,
                            onSignOutComplete = onSignedOut
                        )
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("sign_out_button")
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(stringResource(R.string.sign_out))
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
