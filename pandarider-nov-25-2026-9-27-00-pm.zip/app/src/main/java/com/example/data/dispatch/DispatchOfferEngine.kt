package com.example.data.dispatch

import com.example.data.model.DeliveryOffer
import com.google.android.gms.maps.model.LatLng
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

object DispatchOfferEngine {

    val DEFAULT_CITY_HUB = LatLng(37.7897, -122.4014)

    private data class MerchantSeed(
        val name: String,
        val street: String,
        val latOffset: Double,
        val lngOffset: Double,
        val items: String,
        val itemCount: Int
    )

    private data class CustomerSeed(
        val name: String,
        val street: String,
        val notes: String,
        val latOffset: Double,
        val lngOffset: Double
    )

    private val merchants = listOf(
        MerchantSeed("Sakura Ramen House", "245 Market St", 0.0042, 0.0031, "2x Spicy Miso Ramen, 1x Pork Gyoza", 3),
        MerchantSeed("Panda Bao & Dumpling", "618 Montgomery St", 0.0065, -0.0028, "1x Truffle Xiao Long Bao, 2x Milk Tea", 3),
        MerchantSeed("Firewood Pizza Co.", "410 Howard St", -0.0035, 0.0054, "1x Margherita Pie, 1x Garlic Knots", 2),
        MerchantSeed("Khao Thai Street", "790 Mission St", -0.0048, -0.0039, "1x Pad See Ew, 1x Mango Sticky Rice, 1x Thai Iced Tea", 3),
        MerchantSeed("Seoul Smash Burger", "132 Sutter St", 0.0029, -0.0046, "2x Bulgogi Smash Burger, 1x Kimchi Fries", 3),
        MerchantSeed("Bistro Verde Bowls", "505 Folsom St", -0.0056, 0.0022, "2x Roasted Salmon Poke Bowl", 2)
    )

    private val customers = listOf(
        CustomerSeed("Maya Lin", "580 Howard St, Apt 4B", "Leave with lobby concierge. Code #408.", -0.0029, 0.0048),
        CustomerSeed("Lucas Meyer", "910 Pine St, Suite 7", "Call on arrival at main security gate.", 0.0074, -0.0061),
        CustomerSeed("Priya Nair", "340 Beale St, Unit 12A", "Contact-free drop-off at door mat.", -0.0061, 0.0076),
        CustomerSeed("Ethan Brooks", "1150 Harrison St", "Green awning entrance, ring bell twice.", -0.0085, -0.0052),
        CustomerSeed("Sofia Alvarez", "220 Lombard St, Apt 3", "Wait outside side courtyard gate.", 0.0091, 0.0019),
        CustomerSeed("Noah Takahashi", "675 Townsend St", "Loading dock B reception desk.", -0.0072, 0.0012)
    )

    fun generateOffer(riderCenter: LatLng, sequenceIndex: Int, maxRadiusKm: Int): DeliveryOffer {
        val m = merchants[sequenceIndex % merchants.size]
        val c = customers[(sequenceIndex * 2 + 1) % customers.size]
        val scale = (maxRadiusKm.coerceIn(2, 15) / 8.0).coerceIn(0.6, 1.4)

        val pickupLat = riderCenter.latitude + m.latOffset * scale
        val pickupLng = riderCenter.longitude + m.lngOffset * scale
        val dropLat = riderCenter.latitude + c.latOffset * scale
        val dropLng = riderCenter.longitude + c.lngOffset * scale

        val leg1 = haversineKm(riderCenter.latitude, riderCenter.longitude, pickupLat, pickupLng)
        val leg2 = haversineKm(pickupLat, pickupLng, dropLat, dropLng)
        val totalKm = ((leg1 + leg2) * 10.0).roundToInt() / 10.0

        val basePayCents = (380L + (totalKm * 125).toLong()).coerceAtLeast(420L)
        val surgeBonusCents = if (sequenceIndex % 2 == 0) 150L else 75L
        val tipCents = 200L + ((sequenceIndex % 4) * 100L)
        val orderNum = 4810 + ((sequenceIndex * 37) % 900)
        val etaMin = (totalKm * 4.5 + 6).roundToInt().coerceIn(8, 38)

        return DeliveryOffer(
            offerId = "offer_${sequenceIndex}_${System.currentTimeMillis()}",
            orderCode = "FP-$orderNum",
            restaurantName = m.name,
            restaurantAddress = m.street,
            restaurantLat = pickupLat,
            restaurantLng = pickupLng,
            customerName = c.name,
            dropoffAddress = c.street,
            dropoffNotes = c.notes,
            dropoffLat = dropLat,
            dropoffLng = dropLng,
            itemsSummary = m.items,
            itemCount = m.itemCount,
            distanceKm = totalKm.coerceAtLeast(0.6),
            etaMinutes = etaMin,
            basePayCents = basePayCents,
            tipCents = tipCents,
            surgeBonusCents = surgeBonusCents
        )
    }

    fun hotspotZones(center: LatLng): List<Pair<String, LatLng>> = listOf(
        "Financial Core (+1.5x)" to LatLng(center.latitude + 0.0045, center.longitude + 0.0038),
        "SoMa Food Hub (+$1.50)" to LatLng(center.latitude - 0.0052, center.longitude + 0.0029),
        "Civic Plaza Busy" to LatLng(center.latitude + 0.0021, center.longitude - 0.0064)
    )

    fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2.0) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2.0)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}
