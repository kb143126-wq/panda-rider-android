package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val PandaDarkColorScheme = darkColorScheme(
    primary = PandaPinkBright,
    onPrimary = Color.White,
    primaryContainer = PandaPinkDeep,
    onPrimaryContainer = PandaPinkSoft,
    secondary = PandaMint,
    onSecondary = CharcoalBg,
    secondaryContainer = PandaMintDark,
    onSecondaryContainer = PandaMintSoft,
    tertiary = PandaAmber,
    onTertiary = CharcoalBg,
    background = CharcoalBg,
    onBackground = TextOnDark,
    surface = CharcoalSurface,
    onSurface = TextOnDark,
    surfaceVariant = CharcoalSurfaceHigh,
    onSurfaceVariant = TextMutedDark,
    outline = CharcoalOutline,
    error = ErrorRed,
    onError = Color.White
)

private val PandaLightColorScheme = lightColorScheme(
    primary = PandaPink,
    onPrimary = Color.White,
    primaryContainer = PandaPinkSoft,
    onPrimaryContainer = PandaPinkDeep,
    secondary = PandaMintDark,
    onSecondary = Color.White,
    secondaryContainer = PandaMintSoft,
    onSecondaryContainer = PandaMintDark,
    tertiary = PandaAmber,
    onTertiary = TextOnLight,
    background = IvoryBg,
    onBackground = TextOnLight,
    surface = IvorySurface,
    onSurface = TextOnLight,
    surfaceVariant = IvorySurfaceLow,
    onSurfaceVariant = TextMutedLight,
    outline = IvoryOutline,
    error = ErrorRed,
    onError = Color.White
)

private val PandaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun PandaRiderTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) PandaDarkColorScheme else PandaLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = PandaTypography,
        shapes = PandaShapes,
        content = content
    )
}
