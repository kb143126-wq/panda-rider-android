package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PandaPink = Color(0xFFD70F64)
val PandaPinkBright = Color(0xFFFF2B85)
val PandaPinkSoft = Color(0xFFFFE4EE)
val PandaPinkDeep = Color(0xFF9C0645)

val PandaMint = Color(0xFF00C896)
val PandaMintSoft = Color(0xFFD6F9EF)
val PandaMintDark = Color(0xFF007A5B)

val PandaAmber = Color(0xFFFF9F1C)
val PandaAmberSoft = Color(0xFFFFF1D6)

val CharcoalBg = Color(0xFF101116)
val CharcoalSurface = Color(0xFF181A22)
val CharcoalSurfaceHigh = Color(0xFF232632)
val CharcoalOutline = Color(0xFF343847)

val IvoryBg = Color(0xFFFCF9FA)
val IvorySurface = Color(0xFFFFFFFF)
val IvorySurfaceLow = Color(0xFFF5EFF2)
val IvoryOutline = Color(0xFFE3D7DC)

val TextOnDark = Color(0xFFF7F4F6)
val TextMutedDark = Color(0xFFA7A9B8)
val TextOnLight = Color(0xFF171316)
val TextMutedLight = Color(0xFF6B5F65)

val ErrorRed = Color(0xFFE53935)
val ErrorSoft = Color(0xFFFFEBEE)
