const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_rider_123";
const BOB_UID = "bob_rider_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validProfilePayload(uid, createdAt) {
  return {
    userId: uid,
    displayName: "Alex Rider",
    email: "alex@example.com",
    vehicleType: "E_BIKE",
    preferredZone: "Downtown Central",
    maxRadiusKm: 8,
    online: false,
    thermalBagVerified: true,
    totalEarningsCents: 0,
    completedDeliveries: 0,
    ratingTenths: 49,
    createdAt,
    updatedAt: createdAt,
  };
}

function validDeliveryPayload(uid, createdAt) {
  return {
    userId: uid,
    orderCode: "FP-4821",
    restaurantName: "Sakura Ramen House",
    restaurantAddress: "245 Market St",
    restaurantLat: 37.7915,
    restaurantLng: -122.3982,
    customerName: "Maya Lin",
    dropoffAddress: "580 Howard St, Apt 4B",
    dropoffNotes: "Leave with lobby concierge",
    dropoffLat: 37.7871,
    dropoffLng: -122.3964,
    itemsSummary: "2x Spicy Miso Ramen, 1x Gyoza",
    itemCount: 3,
    distanceKm: 1.8,
    basePayCents: 450,
    tipCents: 300,
    surgeBonusCents: 150,
    totalPayCents: 900,
    status: "HEADING_TO_PICKUP",
    itemsVerified: false,
    createdAt,
    updatedAt: createdAt,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users cannot read or write any rider collections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const now = new Date(Date.now() - 1000);

  await assertFails(unauthDb.collection("riders").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("riders").doc(ALICE_UID).set(validProfilePayload(ALICE_UID, now))
  );
  await assertFails(
    unauthDb.collection("riders").doc(ALICE_UID).collection("deliveries").get()
  );
  await assertFails(
    unauthDb.collection("riders").doc(ALICE_UID).collection("payouts").get()
  );
});

test("Cross-user isolation blocks Bob from reading or writing Alice data", async () => {
  const created = new Date(Date.now() - 10000);
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db.collection("riders").doc(ALICE_UID).set(validProfilePayload(ALICE_UID, created));
    await db
      .collection("riders")
      .doc(ALICE_UID)
      .collection("deliveries")
      .doc("del_1")
      .set(validDeliveryPayload(ALICE_UID, created));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("riders").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("riders").doc(ALICE_UID).update({ online: true, updatedAt: new Date(Date.now() - 500) })
  );
  await assertFails(
    bobDb.collection("riders").doc(ALICE_UID).collection("deliveries").get()
  );
  await assertFails(
    bobDb
      .collection("riders")
      .doc(ALICE_UID)
      .collection("deliveries")
      .doc("del_1")
      .update({ status: "AT_PICKUP", itemsVerified: false, updatedAt: new Date(Date.now() - 500) })
  );
});

test("Rider profile create, partial updates, and validation bounds", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);
  const profileRef = aliceDb.collection("riders").doc(ALICE_UID);

  await assertSucceeds(profileRef.set(validProfilePayload(ALICE_UID, created)));

  // Toggle online status
  await assertSucceeds(
    profileRef.update({
      online: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Update rider preferences
  await assertSucceeds(
    profileRef.update({
      displayName: "Alex P.",
      vehicleType: "SCOOTER",
      preferredZone: "Midtown Hub",
      maxRadiusKm: 12,
      thermalBagVerified: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Increment stats on completion
  await assertSucceeds(
    profileRef.update({
      totalEarningsCents: 900,
      completedDeliveries: 1,
      updatedAt: new Date(Date.now() - 200),
    })
  );

  // Reject ghost field / invalid vehicleType / future timestamp / illegal delete
  await assertFails(
    profileRef.update({
      ratingTenths: 50,
      updatedAt: new Date(Date.now() - 100),
    })
  );
  await assertFails(
    profileRef.update({
      vehicleType: "HELICOPTER",
      updatedAt: new Date(Date.now() - 100),
    })
  );
  await assertFails(
    profileRef.update({
      online: false,
      updatedAt: new Date(Date.now() + 60000),
    })
  );
  await assertFails(profileRef.delete());
});

test("Delivery lifecycle transitions, terminal locking, and payout creation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 20000);
  const deliveriesCol = aliceDb.collection("riders").doc(ALICE_UID).collection("deliveries");
  const delRef = deliveriesCol.doc("del_100");

  // Reject @DocumentId 'id' leakage
  await assertFails(
    deliveriesCol.doc("del_bad").set({
      id: "del_bad",
      ...validDeliveryPayload(ALICE_UID, created),
    })
  );

  // Reject state shortcutting on create
  await assertFails(
    deliveriesCol.doc("del_bad2").set({
      ...validDeliveryPayload(ALICE_UID, created),
      status: "COMPLETED",
    })
  );

  // Create valid delivery
  await assertSucceeds(delRef.set(validDeliveryPayload(ALICE_UID, created)));

  // List query works cleanly on user-scoped subcollection
  await assertSucceeds(deliveriesCol.get());

  // Reject skipping directly from HEADING_TO_PICKUP to COMPLETED
  await assertFails(
    delRef.update({
      status: "COMPLETED",
      completedAt: new Date(Date.now() - 1000),
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Valid step-by-step workflow
  await assertSucceeds(
    delRef.update({
      status: "AT_PICKUP",
      itemsVerified: false,
      updatedAt: new Date(Date.now() - 5000),
    })
  );
  await assertSucceeds(
    delRef.update({
      itemsVerified: true,
      updatedAt: new Date(Date.now() - 4000),
    })
  );
  await assertSucceeds(
    delRef.update({
      status: "HEADING_TO_DROPOFF",
      itemsVerified: true,
      updatedAt: new Date(Date.now() - 3000),
    })
  );
  await assertSucceeds(
    delRef.update({
      status: "AT_DROPOFF",
      itemsVerified: true,
      updatedAt: new Date(Date.now() - 2000),
    })
  );
  await assertSucceeds(
    delRef.update({
      status: "COMPLETED",
      completedAt: new Date(Date.now() - 1000),
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Terminal state locking: no updates or deletes allowed after COMPLETED
  await assertFails(
    delRef.update({
      status: "CANCELLED",
      itemsVerified: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(delRef.delete());

  // Payout create works, update/delete rejected
  const payoutRef = aliceDb.collection("riders").doc(ALICE_UID).collection("payouts").doc("pay_1");
  await assertSucceeds(
    payoutRef.set({
      userId: ALICE_UID,
      amountCents: 900,
      method: "INSTANT_BANK",
      status: "PROCESSED",
      createdAt: new Date(Date.now() - 1000),
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(payoutRef.update({ amountCents: 999999, updatedAt: new Date(Date.now() - 500) }));
  await assertFails(payoutRef.delete());
});
