package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import java.util.Locale

enum class VehicleType(val label: String, val navMode: String) {
    E_BIKE("E-Bike", "b"),
    SCOOTER("Scooter", "l"),
    MOTORCYCLE("Motorcycle", "l"),
    CAR("Car", "d");

    companion object {
        fun fromRaw(raw: String?): VehicleType =
            entries.firstOrNull { it.name == raw } ?: E_BIKE
    }
}

enum class DeliveryStatus(val label: String) {
    HEADING_TO_PICKUP("Heading to Restaurant"),
    AT_PICKUP("At Restaurant"),
    HEADING_TO_DROPOFF("Delivering to Customer"),
    AT_DROPOFF("At Drop-off"),
    COMPLETED("Completed"),
    CANCELLED("Cancelled");

    val isActive: Boolean
        get() = this != COMPLETED && this != CANCELLED

    companion object {
        fun fromRaw(raw: String?): DeliveryStatus =
            entries.firstOrNull { it.name == raw } ?: HEADING_TO_PICKUP
    }
}

enum class PayoutMethod(val label: String) {
    INSTANT_BANK("Instant Bank Transfer"),
    PANDA_WALLET("PandaPay Wallet"),
    WEEKLY_DIRECT("Weekly Direct Deposit");

    companion object {
        fun fromRaw(raw: String?): PayoutMethod =
            entries.firstOrNull { it.name == raw } ?: INSTANT_BANK
    }
}

@Keep
@IgnoreExtraProperties
data class RiderProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val vehicleType: String = VehicleType.E_BIKE.name,
    val preferredZone: String = "Downtown Central",
    val maxRadiusKm: Long = 8L,
    val online: Boolean = false,
    val thermalBagVerified: Boolean = true,
    val totalEarningsCents: Long = 0L,
    val completedDeliveries: Long = 0L,
    val ratingTenths: Long = 49L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val vehicleEnum: VehicleType get() = VehicleType.fromRaw(vehicleType)
    val ratingFormatted: String get() = String.format(Locale.US, "%.1f", ratingTenths / 10.0)
}

@Keep
@IgnoreExtraProperties
data class RiderDelivery(
    @DocumentId val id: String = "",
    val userId: String = "",
    val orderCode: String = "",
    val restaurantName: String = "",
    val restaurantAddress: String = "",
    val restaurantLat: Double = 0.0,
    val restaurantLng: Double = 0.0,
    val customerName: String = "",
    val dropoffAddress: String = "",
    val dropoffNotes: String = "",
    val dropoffLat: Double = 0.0,
    val dropoffLng: Double = 0.0,
    val itemsSummary: String = "",
    val itemCount: Long = 1L,
    val distanceKm: Double = 1.0,
    val basePayCents: Long = 0L,
    val tipCents: Long = 0L,
    val surgeBonusCents: Long = 0L,
    val totalPayCents: Long = 0L,
    val status: String = DeliveryStatus.HEADING_TO_PICKUP.name,
    val itemsVerified: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
    @ServerTimestamp val completedAt: Timestamp? = null
) {
    val statusEnum: DeliveryStatus get() = DeliveryStatus.fromRaw(status)
}

@Keep
@IgnoreExtraProperties
data class RiderPayout(
    @DocumentId val id: String = "",
    val userId: String = "",
    val amountCents: Long = 0L,
    val method: String = PayoutMethod.INSTANT_BANK.name,
    val status: String = "PROCESSED",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val methodEnum: PayoutMethod get() = PayoutMethod.fromRaw(method)
}

data class DeliveryOffer(
    val offerId: String,
    val orderCode: String,
    val restaurantName: String,
    val restaurantAddress: String,
    val restaurantLat: Double,
    val restaurantLng: Double,
    val customerName: String,
    val dropoffAddress: String,
    val dropoffNotes: String,
    val dropoffLat: Double,
    val dropoffLng: Double,
    val itemsSummary: String,
    val itemCount: Int,
    val distanceKm: Double,
    val etaMinutes: Int,
    val basePayCents: Long,
    val tipCents: Long,
    val surgeBonusCents: Long
) {
    val totalPayCents: Long get() = basePayCents + tipCents + surgeBonusCents
}

fun formatCents(cents: Long): String {
    val dollars = cents / 100.0
    return String.format(Locale.US, "$%.2f", dollars)
}

fun formatKm(km: Double): String = String.format(Locale.US, "%.1f km", km)
