package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.dispatch.DispatchOfferEngine
import com.example.data.location.RiderLocationTracker
import com.example.data.model.DeliveryOffer
import com.example.data.model.DeliveryStatus
import com.example.data.model.PayoutMethod
import com.example.data.model.RiderDelivery
import com.example.data.model.RiderPayout
import com.example.data.model.RiderProfile
import com.example.data.model.VehicleType
import com.example.data.model.formatCents
import com.example.data.repository.RiderRepository
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

class RiderViewModel(
    private val repository: RiderRepository,
    private val locationTracker: RiderLocationTracker,
    private val currentUserId: String,
    private val initialDisplayName: String,
    private val initialEmail: String?
) : ViewModel() {

    val profileState: StateFlow<UiState<RiderProfile?>> = repository.observeProfile(currentUserId)
        .map<RiderProfile?, UiState<RiderProfile?>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val root = firestoreError ?: error
            Log.w(TAG, "Error observing rider profile", root)
            emit(UiState.Error(root.message ?: "Failed to load rider profile"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val deliveriesState: StateFlow<UiState<List<RiderDelivery>>> = repository.observeDeliveries(currentUserId)
        .map<List<RiderDelivery>, UiState<List<RiderDelivery>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val root = firestoreError ?: error
            Log.w(TAG, "Error observing deliveries", root)
            emit(UiState.Error(root.message ?: "Failed to load deliveries"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val payoutsState: StateFlow<UiState<List<RiderPayout>>> = repository.observePayouts(currentUserId)
        .map<List<RiderPayout>, UiState<List<RiderPayout>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val root = firestoreError ?: error
            Log.w(TAG, "Error observing payouts", root)
            emit(UiState.Error(root.message ?: "Failed to load payouts"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    private val _riderLocation = MutableStateFlow(DispatchOfferEngine.DEFAULT_CITY_HUB)
    val riderLocation: StateFlow<LatLng> = _riderLocation.asStateFlow()

    private val _hasLocationPermission = MutableStateFlow(locationTracker.hasLocationPermission())
    val hasLocationPermission: StateFlow<Boolean> = _hasLocationPermission.asStateFlow()

    private val _pendingOffer = MutableStateFlow<DeliveryOffer?>(null)
    val pendingOffer: StateFlow<DeliveryOffer?> = _pendingOffer.asStateFlow()

    private val _offerCountdownSec = MutableStateFlow(0)
    val offerCountdownSec: StateFlow<Int> = _offerCountdownSec.asStateFlow()

    private val _shiftSeconds = MutableStateFlow(0L)
    val shiftSeconds: StateFlow<Long> = _shiftSeconds.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private var offerSequence = 0
    private var locationJob: Job? = null
    private var countdownJob: Job? = null
    private var shiftTimerJob: Job? = null

    init {
        viewModelScope.launch {
            repository.ensureProfileExists(initialDisplayName, initialEmail)
                .onFailure { _feedbackMessage.value = it.localizedMessage ?: "Profile initialization error" }
        }
        if (_hasLocationPermission.value) {
            startLocationUpdates()
        }
        observeShiftAndOffers()
    }

    private fun observeShiftAndOffers() {
        viewModelScope.launch {
            profileState.collect { state ->
                val profile = (state as? UiState.Success)?.data
                if (profile?.online == true) {
                    if (shiftTimerJob == null || shiftTimerJob?.isActive != true) {
                        shiftTimerJob = launch {
                            while (true) {
                                delay(1000L)
                                _shiftSeconds.value += 1L
                            }
                        }
                    }
                    val deliveries = (deliveriesState.value as? UiState.Success)?.data.orEmpty()
                    val hasActive = deliveries.any { it.statusEnum.isActive }
                    if (!hasActive && _pendingOffer.value == null) {
                        dispatchNextOffer(profile.maxRadiusKm.toInt())
                    }
                } else {
                    shiftTimerJob?.cancel()
                    shiftTimerJob = null
                    clearPendingOffer()
                }
            }
        }
    }

    fun onLocationPermissionResult(granted: Boolean) {
        _hasLocationPermission.value = granted || locationTracker.hasLocationPermission()
        if (_hasLocationPermission.value) {
            startLocationUpdates()
        }
    }

    private fun startLocationUpdates() {
        if (locationJob?.isActive == true) return
        locationJob = viewModelScope.launch {
            locationTracker.observeLocationUpdates().collect { latLng ->
                _riderLocation.value = latLng
            }
        }
    }

    fun toggleOnline(goOnline: Boolean) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.setOnlineStatus(goOnline)
                .onSuccess {
                    if (goOnline) {
                        val radius = ((profileState.value as? UiState.Success)?.data?.maxRadiusKm ?: 8L).toInt()
                        val hasActive = (deliveriesState.value as? UiState.Success)?.data
                            ?.any { it.statusEnum.isActive } == true
                        if (!hasActive && _pendingOffer.value == null) {
                            dispatchNextOffer(radius)
                        }
                    } else {
                        clearPendingOffer()
                    }
                }
                .onFailure { _feedbackMessage.value = it.localizedMessage ?: "Failed to update shift status" }
            _isBusy.value = false
        }
    }

    fun dispatchNextOffer(maxRadiusKm: Int = 8) {
        offerSequence += 1
        val offer = DispatchOfferEngine.generateOffer(
            riderCenter = _riderLocation.value,
            sequenceIndex = offerSequence,
            maxRadiusKm = maxRadiusKm
        )
        _pendingOffer.value = offer
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            for (sec in 35 downTo 0) {
                _offerCountdownSec.value = sec
                delay(1000L)
            }
            if (_pendingOffer.value?.offerId == offer.offerId) {
                _pendingOffer.value = null
            }
        }
    }

    fun declineOffer() {
        clearPendingOffer()
        _feedbackMessage.value = "Offer declined. Tap Find Next Offer when ready."
    }

    private fun clearPendingOffer() {
        countdownJob?.cancel()
        countdownJob = null
        _pendingOffer.value = null
        _offerCountdownSec.value = 0
    }

    fun acceptPendingOffer() {
        val offer = _pendingOffer.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            repository.acceptOffer(offer)
                .onSuccess {
                    clearPendingOffer()
                    _feedbackMessage.value = "Order ${offer.orderCode} accepted!"
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Failed to accept order"
                }
            _isBusy.value = false
        }
    }

    fun toggleItemsVerified(delivery: RiderDelivery) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.toggleItemsVerified(delivery.id, !delivery.itemsVerified)
                .onFailure { _feedbackMessage.value = it.localizedMessage ?: "Failed to update checklist" }
            _isBusy.value = false
        }
    }

    fun advanceDelivery(delivery: RiderDelivery) {
        val nextStatus = when (delivery.statusEnum) {
            DeliveryStatus.HEADING_TO_PICKUP -> DeliveryStatus.AT_PICKUP
            DeliveryStatus.AT_PICKUP -> DeliveryStatus.HEADING_TO_DROPOFF
            DeliveryStatus.HEADING_TO_DROPOFF -> DeliveryStatus.AT_DROPOFF
            DeliveryStatus.AT_DROPOFF -> DeliveryStatus.COMPLETED
            DeliveryStatus.COMPLETED, DeliveryStatus.CANCELLED -> return
        }
        viewModelScope.launch {
            _isBusy.value = true
            if (nextStatus == DeliveryStatus.COMPLETED) {
                repository.completeDelivery(delivery)
                    .onSuccess {
                        _feedbackMessage.value = "Delivered ${delivery.orderCode}! Earned ${formatCents(delivery.totalPayCents)}"
                    }
                    .onFailure {
                        _feedbackMessage.value = it.localizedMessage ?: "Failed to complete delivery"
                    }
            } else {
                val verified = if (nextStatus == DeliveryStatus.HEADING_TO_DROPOFF) true else delivery.itemsVerified
                repository.advanceDeliveryStatus(delivery.id, nextStatus, verified)
                    .onFailure {
                        _feedbackMessage.value = it.localizedMessage ?: "Failed to advance delivery"
                    }
            }
            _isBusy.value = false
        }
    }

    fun cancelActiveDelivery(delivery: RiderDelivery) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.advanceDeliveryStatus(delivery.id, DeliveryStatus.CANCELLED, delivery.itemsVerified)
                .onSuccess { _feedbackMessage.value = "Order ${delivery.orderCode} cancelled." }
                .onFailure { _feedbackMessage.value = it.localizedMessage ?: "Failed to cancel order" }
            _isBusy.value = false
        }
    }

    fun savePreferences(
        displayName: String,
        vehicleType: VehicleType,
        preferredZone: String,
        maxRadiusKm: Int,
        thermalBagVerified: Boolean
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            repository.updatePreferences(
                displayName = displayName,
                vehicleType = vehicleType,
                preferredZone = preferredZone,
                maxRadiusKm = maxRadiusKm,
                thermalBagVerified = thermalBagVerified
            ).onSuccess {
                _feedbackMessage.value = "Rider preferences saved."
            }.onFailure {
                _feedbackMessage.value = it.localizedMessage ?: "Failed to save preferences"
            }
            _isBusy.value = false
        }
    }

    fun requestCashOut(amountCents: Long, method: PayoutMethod) {
        if (amountCents <= 0L) {
            _feedbackMessage.value = "Complete at least one delivery to cash out."
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            repository.requestPayout(amountCents, method)
                .onSuccess {
                    _feedbackMessage.value = "Cash-out of ${formatCents(amountCents)} submitted via ${method.label}."
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Failed to request cash-out"
                }
            _isBusy.value = false
        }
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    private companion object {
        const val TAG = "RiderViewModel"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
